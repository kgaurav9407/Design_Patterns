package org.example.Creational.Factory.PaymentSystem;

public class PayPalPayment implements Payment{
    @Override
    public void pay(double amount){
        System.out.println("Paying "+amount+" via Paypal");
    }
}
