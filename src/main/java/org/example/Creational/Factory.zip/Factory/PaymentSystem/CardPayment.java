package org.example.Creational.Factory.PaymentSystem;

public class CardPayment implements Payment{
    @Override
    public void pay(double amount){
        System.out.println("Paying "+amount+" via Credit/Debit Card");
    }
}
