package org.example.Creational.Factory.PaymentSystem.WithFactory.RealFactory;

import org.example.Creational.Factory.PaymentSystem.UPIPayment;
import org.example.Creational.Factory.PaymentSystem.Payment;

public class UPICreator extends PaymentCreator{
    @Override
    public Payment createPayment(){
        return new UPIPayment();
    }
}
