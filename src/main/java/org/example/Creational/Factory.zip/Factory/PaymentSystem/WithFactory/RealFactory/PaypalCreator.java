package org.example.Creational.Factory.PaymentSystem.WithFactory.RealFactory;

import org.example.Creational.Factory.PaymentSystem.CardPayment;
import org.example.Creational.Factory.PaymentSystem.PayPalPayment;
import org.example.Creational.Factory.PaymentSystem.Payment;

public class PaypalCreator extends PaymentCreator{
    @Override
    public Payment createPayment(){
        return new PayPalPayment();
    }
}
