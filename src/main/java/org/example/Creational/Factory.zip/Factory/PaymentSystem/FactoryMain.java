package org.example.Creational.Factory.PaymentSystem;

import org.example.Creational.Factory.PaymentSystem.WithFactory.BasicFactory.WithPaymentService;
import org.example.Creational.Factory.PaymentSystem.WithFactory.RealFactory.CardCreator;
import org.example.Creational.Factory.PaymentSystem.WithFactory.RealFactory.PaymentCreator;
import org.example.Creational.Factory.PaymentSystem.WithFactory.RealFactory.UPICreator;

public class FactoryMain {
    public static void main(String args[]){
//        WithoutPaymentService withoutPaymentService=new WithoutPaymentService();
//        withoutPaymentService.processPayment("UPI",200);
//        withoutPaymentService.processPayment("Card",400);
//        withoutPaymentService.processPayment("Paypal",500);


//        WithPaymentService withPaymentService=new WithPaymentService();
//        withPaymentService.processPayment("UPI",200);
//        withPaymentService.processPayment("Card",400);
//        withPaymentService.processPayment("Paypal",500);

        PaymentCreator creator=new CardCreator();
        creator.processPayment(300);

        creator=new UPICreator();
        creator.processPayment(500);

    }
}
