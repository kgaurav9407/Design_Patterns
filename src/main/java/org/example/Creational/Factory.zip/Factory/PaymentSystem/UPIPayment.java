package org.example.Creational.Factory.PaymentSystem;

public class UPIPayment implements Payment{
    @Override
    public void pay(double amount){
        System.out.println("Paying "+amount+"  via UPI");
    }
}
