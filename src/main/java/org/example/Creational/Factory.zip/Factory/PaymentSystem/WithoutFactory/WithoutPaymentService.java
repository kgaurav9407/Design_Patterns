package org.example.Creational.Factory.PaymentSystem.WithoutFactory;
import org.example.Creational.Factory.PaymentSystem.CardPayment;
import org.example.Creational.Factory.PaymentSystem.PayPalPayment;
import org.example.Creational.Factory.PaymentSystem.Payment;
import org.example.Creational.Factory.PaymentSystem.UPIPayment;


public class WithoutPaymentService {
    public void processPayment(String type,double amount){
        Payment payment;
        if(type.equals("UPI"))
            payment=new UPIPayment();
        else if(type.equals("Card"))
            payment=new CardPayment();
        else if(type.equals("Paypal"))
            payment=new PayPalPayment();
        else
            throw new IllegalArgumentException("Invalid payment type");

        payment.pay(amount);
    }
}
