package org.example.Creational.Factory.PaymentSystem.WithFactory.RealFactory;

import org.example.Creational.Factory.PaymentSystem.Payment;

public abstract class PaymentCreator {
    abstract Payment createPayment();

    public void processPayment(double amount){
        Payment payment=createPayment();
        payment.pay(amount);
    }
}
