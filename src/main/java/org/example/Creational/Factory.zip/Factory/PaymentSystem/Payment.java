package org.example.Creational.Factory.PaymentSystem;

public interface Payment {
    void pay(double amount);
}
