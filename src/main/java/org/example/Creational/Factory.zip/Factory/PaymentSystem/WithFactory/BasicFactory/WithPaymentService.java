package org.example.Creational.Factory.PaymentSystem.WithFactory.BasicFactory;

import org.example.Creational.Factory.PaymentSystem.Payment;

public class WithPaymentService {
    public void processPayment(String type,double amount){
        Payment payment=PaymentFactory.getPayment(type);
        payment.pay(amount);
    }
}
